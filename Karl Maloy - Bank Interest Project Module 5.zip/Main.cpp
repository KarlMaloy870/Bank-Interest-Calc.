// Bank Project      Karl Maloy      20230205

#include <iostream>
#include <string>
#include <iomanip>
#include "BankAcc.h"
using namespace std;

//Main function 

int main() {


// sets up a while loop that will prompt the user to make a new chart until they want to quit
	int userChoice = 1;
	int numYear;
	double monDeposit;
	double openVal;
	double interRate;
	BankAcc Bank;

	while (userChoice != 2) {

// prompts the user to enter their values
		cout << endl;
		cout << "Enter a number of years." << endl;
		cin >> numYear;
		cout << "Enter a monthly deposit or for no deposit enter " << "\"0\"." << endl;
		cin >> monDeposit;
		cout << "Enter the starting balance for the account this could be $0, $5, or more. Whatever you wanna start with after all this is your money." << endl;
		cin >> openVal;
		cout << "Enter the yearly interest rate on the account. EX: 5 would mean 5% interest rate." << endl;
		cin >> interRate;


// determines if user input a deposit if they did not then the no deposit functions will be called
		if (monDeposit == 0) {
			Bank.SetInputs(numYear, monDeposit, openVal, interRate);
			Bank.PrintNoDepositHeader();
			Bank.PrintNoDep();
		}



// if the user does input a deposit this branch will execute and the with deposit functions will be called
		else {
			Bank.SetInputs(numYear, monDeposit, openVal, interRate);
			Bank.PrintWithDepositHeader();
			Bank.PrintInterestWithDeposit();
		}



// prompts user at end if they would want to create another chart
		cout << endl;
		cout << endl;
		cout << "Would you like to make another chart?" << endl;
		cout << "Enter 1 for YES" << endl;
		cout << "Enter 2 for NO" << endl;
		cout << endl;
		cin >> userChoice;
	}
	return 0;
}
