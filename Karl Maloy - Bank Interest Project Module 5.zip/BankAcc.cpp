#include "BankAcc.h"


//function that sets and resets variables so the user can create their chart
void BankAcc::SetInputs(int NumYears, double dep, double start, double inter) {

	months = NumYears * 12;
	openingVal = start;
	deposit = dep;
	interestRate = inter;
	interest = 0.0;
	closingVal = 0.0;
	total = 0.0;
	firstCall = true;

}


//creates the function to determine what the interest would be
double BankAcc::GetInterest() {
	interest = (openingVal + deposit) * ((interestRate / 100) / 12);
	return interest;
}




// creates the function to set the starting balance
void BankAcc::SetOpeningVal() {
	if (firstCall) {
		openingVal = openingVal;
		firstCall = false;
	}
	else {
		openingVal = closingVal;
	}
}




// creates the function that will give the user their starting balance 
double BankAcc::GetOpeningVal() {
	return openingVal;
}




// creates the function that will return the users ending balance without a monthly deposit
double BankAcc::GetClosingValNoDeposit() {
	closingVal = openingVal + GetInterest();
	return closingVal;
}




// gets the users total by adding their starting balance with their deposit
double BankAcc::GetTotal() {
	total = openingVal + deposit;
	return total;
}




// creates the function that will return the users end balance with a monthly deposit
double BankAcc::GetClosingValWithDeposit() {
	closingVal = GetTotal() + GetInterest();
	return closingVal;
}




// prints out header chart for no monthly deposit
void BankAcc::PrintNoDepositHeader() {
	cout << endl;
	cout << endl;
	cout << string(85, '=') << endl;
	cout << "$" << string(19, ' ') << "Balance And Intrest Without A Monthly Deposit" << string(19, ' ') << "$" << endl;
	cout << string(85, '-') << endl;
	cout << "|" << string(2, ' ') << "Month" << string(8, ' ') << "Starting Balance" << string(11, ' ') <<
		"Interest" << string(17, ' ') << "Ending Balance" << "  |" << endl;
	cout << string(85, '=') << endl;
}




// print the values with no monthly deposit
void BankAcc::PrintNoDep() {
	int i;
	int monthCount = 1;
	for (i = 1; i <= months; ++i) {
		SetOpeningVal();
		cout << "|  " << setw(3) << left << setfill(' ') << monthCount << string(10, ' ') << "$" << setw(26) << left <<
			setfill(' ') << fixed << showpoint << setprecision(2) << GetOpeningVal() << "$" << setw(24) << left << setfill(' ') <<
			fixed << showpoint << setprecision(2) << GetInterest() << "$" << setw(15) << left << setfill(' ') <<
			fixed << showpoint << setprecision(2) << GetClosingValNoDeposit() << "|" << endl;
		cout << string(85, '-');
		cout << endl;
		++monthCount;
	}
}




// function for interest with deposits
void BankAcc::PrintWithDepositHeader() {
	cout << endl;
	cout << endl;
	cout << string(131, '=') << endl;
	cout << "$" << string(44, ' ') << "Balance And Intrest With A Monthly Deposit" << string(43, ' ') << "$" << endl;
	cout << string(131, '-') << endl;
	cout << "|  " << "Month" << string(13, ' ') << "Starting Balance" << string(10, ' ') << "Monthly Deposit" <<
		string(8, ' ') << "Total" << string(14, ' ') << "Interest" << string(17, ' ') << "Ending Balance" << string(2, ' ') <<
		"|" << endl;
	cout << string(131, '=') << endl;
}




// this function prints out the vales with a monthly deposit included
void BankAcc::PrintInterestWithDeposit() {
	int i;
	int monthCount = 1;
	for (i = 1; i <= months; ++i) {
		SetOpeningVal();
		cout << "|  " << setw(3) << left << setfill(' ') << monthCount << string(15, ' ') << "$" << setw(23) << left << setfill(' ') <<
			fixed << showpoint << setprecision(2) << GetOpeningVal() << string(2, ' ') << "$" << setw(22) << left << setfill(' ') <<
			fixed << showpoint << setprecision(2) << deposit << "$" << setw(18) << left << setfill(' ') << fixed <<
			showpoint << setprecision(2) << GetTotal() << "$" << setw(24) << left << setfill(' ') <<
			fixed << showpoint << setprecision(2) << GetInterest() << "$" << setw(15) << left << setfill(' ') <<
			fixed << showpoint << setprecision(2) << GetClosingValWithDeposit() << "|" << endl;
		cout << string(131, '-');
		cout << endl;
		++monthCount;
	}
}