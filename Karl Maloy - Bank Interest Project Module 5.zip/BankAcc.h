#pragma once
#ifndef BANKACC_H
#define BANKACC_H
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

// creates the Bank Account class named BankAcc
class BankAcc {


// creates variable to be used through out functions and code.
private:

	int years = 0;
	int months = 0;
	double deposit = 0.0;
	double interest = 0.0;
	double interestRate = 0.0;
	double openingVal = 0.0;
	double closingVal = 0.0;
	double total = 0.0;
	bool firstCall = true;



public:

//function that sets and resets variables so the user can create their chart
	void SetInputs(int NumYears, double dep, double start, double inter);




//creates the function to determine what the interest would be
	double GetInterest();




// creates the function to set the starting balance
	void SetOpeningVal();




// creates the function that will give the user their starting balance 
	double GetOpeningVal();




// creates the function that will return the users ending balance without a monthly deposit
	double GetClosingValNoDeposit();




// gets the users total by adding their starting balance with their deposit
	double GetTotal();




// creates the function that will return the users end balance with a monthly deposit
	double GetClosingValWithDeposit();




// prints out header chart for no monthly deposit
	void PrintNoDepositHeader();




// print the values with no monthly deposit
	void PrintNoDep();




// function for interest with deposits
	void PrintWithDepositHeader();




// this function prints out the vales with a monthly deposit included
	void PrintInterestWithDeposit();



};
#endif
